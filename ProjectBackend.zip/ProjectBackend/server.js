const express = require('express');
const mongoose = require('mongoose');
const contactRoutes = require('./backend/routes/contactRoutes');
const userRoutes = require('./backend/routes/userRoutes');

const app = express();
const PORT = 3001;

// Connect to MongoDB
mongoose.connect("mongodb+srv://akashhere33:<oa0R8TKcO38e6KWV>@cluster0.6sv0l.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('MongoDB connection error:', error);
});

// Middleware
app.use(express.json());
app.use('/api/contacts', contactRoutes);
app.use('/api/users', userRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
